package ratings.datastructures;

public class SongBayesianRatingComparator {
}
