package ratings.datastructures;

public class SongTitleComparator {
}
